// ********************************************
//   Problems.java
// 
//   Provide lots of syntax errors for the user to correct.
//          
 ********************************************

public class problems
{

    public Static main (string[] args)
    {

	System.out.println ("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
	System.out.println (This program used to have lots of problems,");
	System.0ut.println ("but if it prints this, you fixed them all.")
	System.out.println ("             *** Hurray! ***);
	System.out.println ("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

    }
}
