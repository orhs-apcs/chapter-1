public class Count
{

    public static void main (String[] args)
    {

	System.out.println ("one two three four five");
	System.out.println ("un deux trois quatre cinq");
	System.out.println ("uno dos tres cuatro cinco");

    }

}
