
// ********************************************
//  Simple.java
// 
//  Print a simple message about Java.
//          
// ********************************************

public class Simple
{

    public static void main (String[] args)
    {

	System.out.println ("Java rocks!!");

    }
}
